export const LOGIN_ROUTE = "/";
export const POSTS_ROUTE = "/posts";
export const LOGOUT_ROUTE = "/logout";
export const PROFILE_ROUTE = "/profile"
